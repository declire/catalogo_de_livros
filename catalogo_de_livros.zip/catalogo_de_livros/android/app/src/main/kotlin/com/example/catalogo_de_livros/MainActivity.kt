package com.example.catalogo_de_livros

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
